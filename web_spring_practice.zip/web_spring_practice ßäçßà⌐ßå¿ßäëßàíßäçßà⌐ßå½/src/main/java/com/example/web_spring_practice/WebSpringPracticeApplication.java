package com.example.web_spring_practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebSpringPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebSpringPracticeApplication.class, args);
	}

}
